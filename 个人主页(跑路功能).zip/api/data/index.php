<?php
// 禁止直接访问
http_response_code(403);
echo 'Access Denied';
